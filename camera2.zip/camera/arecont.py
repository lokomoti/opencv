import time
import math


def timestamp():
    millis = int(round(time.time() * 1000))
    return millis


# Function that gets configurations from json
def get_config(device_number):
    from python_json_config import ConfigBuilder

    # create config parser
    builder = ConfigBuilder()

    # parse config
    config = builder.parse_config('config.json')

    # access elements

    data = config.program
    print(data)


# def stream_url(device_number):
#     ip_addr, port, user, password, res, frame_w, frame_h, quality, doublescan, bitrate, fps = get_config(
#         device_number)
#     url = "rtsp://" + user + ":" + password + "@" + ip_addr + ":" + port + "/h264.sdp?res=" + res + \
#           "&x0=0&y0=0&x1=" + frame_w + "&y1=" + frame_h + \
#           "&qp=" + quality + "&doublescan=" + doublescan + "&bitrate=" + bitrate + "&fps=" + fps
#     rtsp_url = str(url)
#     return rtsp_url
#
#
# def http_get_url(device_number):
#     ip_addr, port, user, password, res, frame_w, frame_h, quality, doublescan, bitrate, fps = get_config(
#         device_number)
#     http_get = "http://" + ip_addr + '/get?'
#     return http_get
#
#
# def get_io(ip, user, password, args):
#     request = "http://" + str(ip) + "/get?" + str(args)
#     print(str(request))
#     try:
#         r = requests.get(request, auth=(user, password))
#         print(r.text)
#         return r.text
#     except requests.exceptions.ConnectionError:
#         print("error, host not found")
#     finally:
#         return


def angle(x0, y0, x1, y1, x2, y2):
    print("nothing here so far")


def distance(x0, y0, x1, y1):
    a = (x1 - x0) ** 2
    b = (y1 - y0) ** 2
    return math.sqrt(a + b)


def center(x0, y0, x1, y1):
    a = (x1 - x0) ** 2
    b = (y1 - y0) ** 2
    return int(math.sqrt(a + b) / 2)


def diagDiff(list):  # list of 4 points

    # diagonal A
    x1 = list.ravel()[0]
    y1 = list.ravel()[1]
    x3 = list.ravel()[4]
    y3 = list.ravel()[5]

    d1 = distance(x1, y1, x3, y3)

    # diagonal B
    x2 = list.ravel()[2]
    y2 = list.ravel()[3]
    x4 = list.ravel()[6]
    y4 = list.ravel()[7]

    d2 = distance(x2, y2, x4, y4)

    if (d1 > d2):
        dif = d1 / d2
    else:
        dif = d2 / d1

    return round(dif, 2)


'''
Documentation

file:///C:/Users/jakned/Downloads/Arecont%20Vision%20API%20and%20Camera%20Web%20Page%20Manual_2017-06-30_1.pdf
https://http-api.arecontvision.com/#tag/h.264-Streaming
'''
