from sys import stderr, stdout
import time
import socket
import cv2
import imutils
import numpy as np
from python_json_config import ConfigBuilder
import camera.arecont as ar


# Function to Get config data from json file
def get_config():
    try:
        builder = ConfigBuilder()  # create config parser
        config_get = builder.parse_config('config.json')  # parse config
        return config_get
    except:
        stderr.write("error")


def nothing(x):
    # any operation
    pass

# Get configuration varianbles
config = get_config()
stderr.write("config get OK\n")


TCP_IP = '127.0.0.1'
TCP_PORT = int(config.program.serverSettings.port)
BUFFER_SIZE = int(config.program.serverSettings.bufferSize)  # Normally 1024, but we want fast response

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((TCP_IP, TCP_PORT))
s.listen(1)

conn, addr = s.accept()
stderr.write(str(conn) +"\n")
stderr.write(str(addr) +"\n")

# def distCoor(x1, y1, x2, y2):
#    a = int(pow((x2 - x1),2))
#    b = int(pow((y2 - y1),2))
#    c = math.sqrt(a + b)
#    return int(c)

# Setup variables:
font = cv2.FONT_HERSHEY_SIMPLEX  # font variable
diffTr = 1.7
path = config.program.imageProcessing.videoPath
cap = cv2.VideoCapture(path)
angle = config.program.imageProcessing.imageRotationAngle

l_h = config.program.imageProcessing.lH
l_s = config.program.imageProcessing.lS
l_v = config.program.imageProcessing.lV
u_h = config.program.imageProcessing.uH
u_s = config.program.imageProcessing.uS
u_v = config.program.imageProcessing.uV

min_size = config.program.imageProcessing.minSize
maxCount = config.program.imageProcessing.maxCount
maxSize = config.program.imageProcessing.maxSize
min_corners = config.program.imageProcessing.minCorners
detect_enable = config.program.imageProcessing.detectionEnable

# try if video stream works

print("video OK!")

# set input resolution
cap.set(3, 720)
cap.set(4, 1280)
tra = int(cap.get(3))
trb = int(cap.get(4))

# create two gui windows
cv2.namedWindow("Frame")

# move windows after start so both are visible
cv2.moveWindow("Frame", 0, 0)

# start loop

while True:
    # frameMat = cap.read()
    # Frame = cv2.UMat(frameMat)
    ret, frame_raw = cap.read()
    frame = imutils.rotate(frame_raw, angle)
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # reset count value
    count = 0

    # create numpy arrays from HSV color values
    lower_red = np.array([l_h, l_s, l_v])
    upper_red = np.array([u_h, u_s, u_v])

    # video feed used for image processing
    mask = cv2.inRange(hsv, lower_red, upper_red)
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.erode(mask, kernel)

    # Thumbnail version of mask video along with trackbars
    r = 240.0 / mask.shape[1]
    dim = (320, int(mask.shape[0] * r))
    maskMini = cv2.resize(mask, dim, interpolation=cv2.INTER_AREA)

    # Contours detection
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # for each countour in this list do:
    for cnt in contours:
        area = cv2.contourArea(cnt)
        approx = cv2.approxPolyDP(cnt, 0.02 * cv2.arcLength(cnt, True), True)
        x = approx.ravel()[0]
        y = approx.ravel()[1]
        # if it has 4 corners, area in range, no more that max count, no bigger than max - go next:
        if len(approx) == min_corners and (area > int(min_size * 100) and (maxCount > count)) and (area < (maxSize * 1000)) and detect_enable is True:
            # if diagonals of polygon are same, draw objects
            if ar.diagDiff(approx) < diffTr:  # corners:

                # draw outlines
                cv2.drawContours(frame, [approx], 0, (0, 0, 0), 2)

                # increment counter for each object
                count = count + 1

                # return difference in diagonals
                diff = ar.diagDiff(approx)

                # calculate x,y coordinate of center, insert label
                M = cv2.moments(cnt)
                cntX = int(M["m10"] / M["m00"])
                cntY = int(M["m01"] / M["m00"])
                cv2.putText(frame, str(count) + ".", (int(cntX), int(cntY)), font, 1, (0, 0, 255))

                # parsing width, lenght data array
                x1 = x
                y1 = y
                x2 = approx.ravel()[2]
                y2 = approx.ravel()[3]
                x3 = approx.ravel()[4]
                y3 = approx.ravel()[5]
                x4 = approx.ravel()[6]
                y4 = approx.ravel()[7]

                # calculate diagonals and compare them, exclude objects
                dist1 = ar.distance(x1, y1, x2, y2)
                # print(dist1)

                # draw diagonal A
                pts1 = np.array([[x1, y1], [x3, y3]], np.int32)
                cv2.polylines(frame, [pts1], True, (0, 0, 0))

                # place text in the middle of the objects
                xC = ((x + x3) / 2)
                yC = ((y + y3) / 2)

                # print letter to each corner of an object
                cv2.putText(frame, "A", (int(x), int(y)), font, 0.5, (255, 255, 255))
                cv2.putText(frame, "B", (int(x2), int(y2)), font, 0.5, (255, 255, 255))
                cv2.putText(frame, "C", (int(x3), int(y3)), font, 0.5, (255, 255, 255))
                cv2.putText(frame, "D", (int(x4), int(y4)), font, 0.5, (255, 255, 255))
                # cv2.putText(frame, str(count)+".", (int(xC), int(yC)), font, 1, (0, 0, 255))

                cv2.putText(frame, "sqareness: " + str(diff), (x - 20, y - 40), font, 0.5, (0, 0, 255))
                cv2.putText(frame, "area: " + str(area), (x - 20, y - 20), font, 0.5, (255, 0, 0))
                cv2.circle(frame, (x4, y4), 3, (0, 255, 0), -1)

    # Draw text inform. overlay
    cv2.putText(frame, str(time.strftime("%a, %d %b %Y %H:%M:%S ")), (130, 30), font, 0.5, (255, 255, 255))
    cv2.putText(frame, "Unit count: " + str(count), (5, 15), font, 0.5, (255, 0, 0))
    cv2.putText(frame, "Max units: " + str(maxCount), (5, 30), font, 0.5, (255, 0, 0))
    cv2.putText(frame, "Resolution: " + str(cap.get(3)) + " x " + str(cap.get(4)), (130, 15), font, 0.5, (255, 255, 255))

    # Set prewiev window to size
    rat = int(cap.get(3)) / int(cap.get(4))
    winSize = 0.5
    ax = int(trb * winSize * rat)
    by = int(trb * winSize)

    # final = cv2.resize(frame,(ax, by), interpolation = cv2.INTER_AREA)
    cv2.imshow("Frame", frame)
    cv2.imshow("Mask", maskMini)

    data = (str(count)).encode()
    conn.send(data)

    key = cv2.waitKey(1)
    if key == 27:
        break

conn.close()
cap.release()
cv2.destroyAllWindows()